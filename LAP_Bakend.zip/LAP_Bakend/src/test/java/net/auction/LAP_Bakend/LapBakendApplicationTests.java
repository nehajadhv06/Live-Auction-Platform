package net.auction.LAP_Bakend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LapBakendApplicationTests {

	@Test
	void contextLoads() {
	}

}
