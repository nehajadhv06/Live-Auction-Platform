package net.auction.LAP_Bakend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LapBakendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LapBakendApplication.class, args);
	}

}
