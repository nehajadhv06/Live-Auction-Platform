import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuctionServiceService {
  [x: string]: any;

  constructor() { }
}
