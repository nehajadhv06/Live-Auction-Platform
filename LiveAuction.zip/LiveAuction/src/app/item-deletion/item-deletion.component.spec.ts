import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemDeletionComponent } from './item-deletion.component';

describe('ItemDeletionComponent', () => {
  let component: ItemDeletionComponent;
  let fixture: ComponentFixture<ItemDeletionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ItemDeletionComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ItemDeletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
