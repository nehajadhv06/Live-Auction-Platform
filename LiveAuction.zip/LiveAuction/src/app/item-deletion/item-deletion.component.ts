import { Component } from '@angular/core';

@Component({
  selector: 'app-item-deletion',
  templateUrl: './item-deletion.component.html',
  styleUrl: './item-deletion.component.css'
})
export class ItemDeletionComponent {

}
