// user-registration.component.ts
import { Component, OnInit } from '@angular/core';
import { UserService } from '../user-service.service';
import { User } from '../user';
import { Registration } from '../registration';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  user: User = new User();
  registration: Registration = new Registration('', '', '', '');
  errorMessage!: string;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  registerUser() {
    this.userService.registerUser(this.registration, this.user).subscribe(
      (response) => {
        console.log('User registered successfully:', response);
        // Reset user object after successful registration
        this.user = new User();
        this.registration = new Registration('', '', '', '');
      },
      (error) => {
        console.error('Error registering user:', error);
        this.errorMessage = 'Failed to register user.';
      }
    );
  }

  deleteUser() {
    this.userService.deleteUser(this.user.id).subscribe(
      (response) => {
        console.log('User deleted successfully:', response);
        // Reset user object after successful deletion
        this.user = new User();
      },
      (error) => {
        console.error('Error deleting user:', error);
        this.errorMessage = 'Failed to delete user.';
      }
    );
  }

  updateUser() {
    this.userService.updateUser(this.user).subscribe(
      (response) => {
        console.log('User updated successfully:', response);
        // Reset user object after successful update
        this.user = new User();
      },
      (error) => {
        console.error('Error updating user:', error);
        this.errorMessage = 'Failed to update user.';
      }
    );
  }
}
