import { Component, OnInit } from '@angular/core';
import { Item } from '../item';
import { AuctionServiceService } from '../auction-service.service';

@Component({
  selector: 'app-item-listing',
  templateUrl: './item-listing.component.html',
  styleUrl: './item-listing.component.css'
})
export class ItemListingComponent implements OnInit {
  items: Item[] = [];

  constructor(private auctionService: AuctionServiceService) { }

  ngOnInit(): void {
    this.loadItems();
  }

  loadItems(): void {
    this.auctionService['getAllItems']()
      .subscribe((items: Item[]) => {
        this.items = items;
      });
  }

  viewItemDetails(itemId: number): void {
    // Navigate to item details page or open a modal with item details
  }
}
