export class Registration {
    username!: string;
    email!: string;
    password!: string;
    role!: string;
  
    
    }