import { Component } from '@angular/core';

@Component({
  selector: 'app-bid-form',
  templateUrl: './bid-form.component.html',
  styleUrl: './bid-form.component.css'
})
export class BidFormComponent {

}
