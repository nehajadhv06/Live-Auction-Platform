import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { ItemListingComponent } from './item-listing/item-listing.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { ItemCreationComponent } from './item-creation/item-creation.component';
import { ItemUpdateComponent } from './item-update/item-update.component';
import { ItemDeletionComponent } from './item-deletion/item-deletion.component';
import { BidFormComponent } from './bid-form/bid-form.component';

@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    UserLoginComponent,
    ItemListingComponent,
    ItemDetailsComponent,
    ItemCreationComponent,
    ItemUpdateComponent,
    ItemDeletionComponent,
    BidFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
