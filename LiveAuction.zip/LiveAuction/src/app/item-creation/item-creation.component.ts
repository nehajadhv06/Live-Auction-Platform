import { Component } from '@angular/core';

@Component({
  selector: 'app-item-creation',
  templateUrl: './item-creation.component.html',
  styleUrl: './item-creation.component.css'
})
export class ItemCreationComponent {

}
